# Proof of Concept (POC): Google Knowledge Catalog Implementation

## Project Overview
This document outlines the Proof of Concept (POC) for implementing a **Google Knowledge Catalog** (leveraging Google Cloud Data Catalog / Dataplex).

## Directory Structure
```text
 cloud_run/
  └─ bulk_aspect_apply/
    ├─ main.py
    ├─ Dockerfile.txt
    ├─ requirements.txt
    └─ config.yaml


 terraform_code/
   ├─ custom_modules/
   │  ├─ dataplex_aspect_type/
   │  │  ├─ main.tf
   │  │  ├─ outputs.tf
   │  │  └─ variables.tf
   │  ├─ dataplex_datascan/
   │  │  ├─ data-profiling/
   │  │  │  ├─ main.tf
   │  │  │  ├─ outputs.tf
   │  │  └─ variables.tf
   │  │  └─ data-quality/
   │  │     ├─ main.tf
   │  │     ├─ outputs.tf
   │  │     └─ variables.tf
   │  └─ dataplex_iam/
   │     ├─ main.tf
   │     └─ variables.tf
   └─ envs/
      └─ dev/
         ├─ .terraform.lock.hcl
         ├─ datablex.tf
         ├─ datablex.tf
         ├─ providers.tf
         ├─ terraform.tfvars
         └─ variables.tf

```

