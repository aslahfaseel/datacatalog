import argparse
import json
import logging
import os
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List

try:
    from google.cloud import bigquery, dataplex_v1
    from google.protobuf.json_format import MessageToDict
except ImportError as err:
    print(
        f"Missing required dependencies: {err}\n"
        "Please run: pip install google-cloud-dataplex google-cloud-bigquery protobuf"
    )
    sys.exit(1)

# Configure logging format
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def load_config(config_path: str) -> Dict[str, Any]:
    """Reads and validates the JSON configuration file.

    Args:
        config_path (str): Path to the config JSON file.

    Returns:
        Dict[str, Any]: Parsed configuration object.
    """
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found at: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        try:
            config = json.load(f)
        except json.JSONDecodeError as err:
            raise ValueError(f"Invalid JSON format in {config_path}: {err}") from err

    # Validate mandatory source keys
    required_source = ["project_id", "location", "dataset_id", "table_id"]
    for key in required_source:
        if key not in config.get("source", {}):
            raise KeyError(f"Missing required key 'source.{key}' in configuration file.")

    # Validate mandatory destination keys
    required_dest = ["project_id", "dataset_id", "table_id"]
    for key in required_dest:
        if key not in config.get("destination", {}):
            raise KeyError(f"Missing required key 'destination.{key}' in configuration file.")

    return config


def fetch_dataplex_aspects(
        catalog_client: dataplex_v1.CatalogServiceClient,
        source_cfg: Dict[str, Any]
) -> Dict[str, Any]:
    """Retrieves full entry details and attached aspects from Dataplex Catalog."""
    project_id = source_cfg["project_id"]
    location = source_cfg["location"]
    entry_group = source_cfg.get("entry_group_id", "@bigquery")
    dataset_id = source_cfg["dataset_id"]
    table_id = source_cfg["table_id"]

    entry_id = f"bigquery.googleapis.com/projects/{project_id}/datasets/{dataset_id}/tables/{table_id}"
    entry_name = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group}/entries/{entry_id}"

    logging.info(f"Fetching Dataplex Catalog entry to discover aspects: {entry_name}")

    # STEP 1: Fetch with FULL view just to see which aspects exist
    initial_request = dataplex_v1.GetEntryRequest(
        name=entry_name,
        view=dataplex_v1.EntryView.FULL
    )

    try:
        initial_entry = catalog_client.get_entry(request=initial_request)
    except Exception as err:
        logging.error(f"Failed to fetch initial entry from Dataplex Catalog: {err}")
        raise

    # 🚨 UPDATED: Parse the shorthand keys and build the fully qualified resource names
    aspect_types_set = set()
    for key in initial_entry.aspects.keys():
        # 1. Strip the column-level path (e.g., '@Schema.last_name')
        base_type = key.split("@")[0]

        # 2. Split the shorthand key (e.g., '655216118709.global.queries')
        parts = base_type.split(".")

        # 3. Format into the exact fully qualified resource name required by the API
        if len(parts) == 3:
            resource_name = f"projects/{parts[0]}/locations/{parts[1]}/aspectTypes/{parts[2]}"
            aspect_types_set.add(resource_name)
        else:
            aspect_types_set.add(base_type)  # Fallback

    aspect_types_list = list(aspect_types_set)

    if not aspect_types_list:
        logging.info("No aspects found on this entry.")
        return initial_entry.name, {}

    logging.info(f"Discovered {len(aspect_types_list)} unique aspect type(s). Fetching data payloads...")

    # STEP 2: Make a CUSTOM request asking for the explicit, properly formatted resource names
    full_request = dataplex_v1.GetEntryRequest(
        name=entry_name,
        view=dataplex_v1.EntryView.CUSTOM,
        aspect_types=aspect_types_list
    )

    try:
        full_entry = catalog_client.get_entry(request=full_request)
        return full_entry.name, full_entry.aspects
    except Exception as err:
        logging.error(f"Failed to fetch detailed aspects: {err}")
        raise

def process_aspects(
        entry_name: str,
        aspects: Dict[str, Any],
        source_cfg: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """Transforms raw protobuf aspect objects into structured dictionaries for BigQuery."""
    rows = []
    current_time = datetime.now(timezone.utc).isoformat()

    for aspect_type, aspect_obj in aspects.items():
        # Native Google Cloud parser that handles nested arrays flawlessly
        aspect_dict = type(aspect_obj).to_dict(aspect_obj)

        # Extract the actual 'data' dictionary, fallback to the full dict if missing
        data_payload = aspect_dict.get("data")
        if not data_payload:
            data_payload = aspect_dict

        row = {
            "source_project": source_cfg["project_id"],
            "source_dataset": source_cfg["dataset_id"],
            "source_table": source_cfg["table_id"],
            "dataplex_entry_name": entry_name,
            "aspect_type": aspect_type,
            # "aspect_data": json.dumps(data_payload),
            "aspect_data": data_payload,
            "create_time": aspect_dict.get("create_time"),
            "update_time": aspect_dict.get("update_time"),
            "extracted_at": current_time,
        }
        rows.append(row)

    return rows

def load_to_bigquery(
        bq_client: bigquery.Client,
        dest_cfg: Dict[str, Any],
        rows: List[Dict[str, Any]]
) -> None:
    """Loads transformed aspect records into the target BigQuery table.

    Args:
        bq_client: Initialized BigQuery client.
        dest_cfg: Destination table configuration.
        rows: Transformed aspect dictionaries.
    """
    dest_project = dest_cfg["project_id"]
    dest_dataset = dest_cfg["dataset_id"]
    dest_table = dest_cfg["table_id"]
    target_table_id = f"{dest_project}.{dest_dataset}.{dest_table}"

    write_disp = dest_cfg.get("write_disposition", "WRITE_APPEND").upper()
    disposition_enum = getattr(bigquery.WriteDisposition, write_disp, bigquery.WriteDisposition.WRITE_APPEND)

    schema = [
        bigquery.SchemaField("source_project", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("source_dataset", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("source_table", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("dataplex_entry_name", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("aspect_type", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("aspect_data", "JSON", mode="NULLABLE"),
        bigquery.SchemaField("create_time", "TIMESTAMP", mode="NULLABLE"),
        bigquery.SchemaField("update_time", "TIMESTAMP", mode="NULLABLE"),
        bigquery.SchemaField("extracted_at", "TIMESTAMP", mode="REQUIRED"),
    ]

    job_config = bigquery.LoadJobConfig(
        schema=schema,
        write_disposition=disposition_enum,
    )

    logging.info(f"Loading {len(rows)} record(s) into BigQuery table: {target_table_id}")
    load_job = bq_client.load_table_from_json(rows, target_table_id, job_config=job_config)

    load_job.result()  # Wait for loading job to finish
    logging.info(f"Successfully loaded aspect data into {target_table_id}.")


def main():
    parser = argparse.ArgumentParser(
        description="Extract Dataplex aspects from Table A and load into BigQuery Table B.")
    parser.add_argument(
        "--config",
        type=str,
        default="config.json",
        help="Path to the JSON configuration file (default: config.json)",
    )
    args = parser.parse_args()

    # 1. Load Configuration
    config = load_config(args.config)
    source_cfg = config["source"]
    dest_cfg = config["destination"]

    # 2. Initialize GCP Clients
    catalog_client = dataplex_v1.CatalogServiceClient()
    bq_client = bigquery.Client(project=dest_cfg["project_id"])

    # 3. Extract Aspects
    entry_name, aspects = fetch_dataplex_aspects(catalog_client, source_cfg)

    if not aspects:
        logging.info("No aspects found attached to the specified source table.")
        return

    # 4. Transform Records
    rows = process_aspects(entry_name, aspects, source_cfg)

    # 5. Load to Destination Table
    load_to_bigquery(bq_client, dest_cfg, rows)


if __name__ == "__main__":
    main()
