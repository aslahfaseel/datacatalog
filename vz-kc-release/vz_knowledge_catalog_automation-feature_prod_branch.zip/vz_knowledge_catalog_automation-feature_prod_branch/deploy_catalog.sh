#!/bin/bash
alias gcloud='/apps/opt/application/google-cloud-sdk/bin/gcloud'
set -x
echo "Executing from deploy_catalog.sh"

WORKSPACE_DIR=$1
BRANCH_NAME=$2
GIT_COMMIT_HASH=$3

# Map branch directly to environment folder
if [ "$BRANCH_NAME" = "master" ] || [ "$BRANCH_NAME" = "main" ]; then
    targetenv="prod"
    UPSTREAM_DEFAULT="origin/master"
else
    targetenv="dev"
    UPSTREAM_DEFAULT="origin/dev"
fi

echo "Dynamic context target environment resolved to: ${targetenv}"

# --- Refresh GCP Auth token ---
set +x 
. ~/.bash_profile
set -x

export http_proxy=http://proxy.ebiz.verizon.com:80
export https_proxy=http://proxy.ebiz.verizon.com:80
setPRDenv
# ------------------------------

cd ${WORKSPACE_DIR} 
echo "Detecting changes for deployment..."

git fetch --depth=5 2>/dev/null
DIFF_FILES=$(git diff --name-only HEAD~1 HEAD 2>/dev/null)

if [ $? -ne 0 ] || [ -z "$DIFF_FILES" ]; then
    echo "First run on a new branch detected. Checking changes against remote origin..."
    UPSTREAM_BRANCH=$(git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null || echo "${UPSTREAM_DEFAULT}")
    git fetch origin $(echo $UPSTREAM_BRANCH | cut -d/ -f2) --depth=5 2>/dev/null
    DIFF_FILES=$(git diff --name-only $UPSTREAM_BRANCH HEAD 2>/dev/null)
fi

APPS_CHANGED=$(echo "$DIFF_FILES" | grep "^cloud_run/" | cut -d/ -f2 | sort | uniq)
TF_CHANGED=$(echo "$DIFF_FILES" | grep "^terraform_code/envs/${targetenv}/cloud_run/" | cut -d/ -f5 | sort | uniq)

SHARED_CR_CHANGED=$(echo "$DIFF_FILES" | grep "^terraform_code/custom_modules/cloudrun_job/")
if [ ! -z "$SHARED_CR_CHANGED" ]; then
    echo "Shared Cloud Run module updated. Queueing all apps for fresh deployments."
    TF_CHANGED=$(ls -1 ${WORKSPACE_DIR}/cloud_run/ 2>/dev/null)
fi

ALL_CHANGED_CLOUDRUN=$(echo -e "$APPS_CHANGED\n$TF_CHANGED" | sed '/^$/d' | sort | uniq)

DATAPLEX_ENV_CHANGED=$(echo "$DIFF_FILES" | grep "^terraform_code/envs/${targetenv}/dataplex/")
SHARED_DP_CHANGED=$(echo "$DIFF_FILES" | grep "dataplex_")

if [ ! -z "$DATAPLEX_ENV_CHANGED" ] || [ ! -z "$SHARED_DP_CHANGED" ]; then
    DATAPLEX_CHANGED="true"
else
    DATAPLEX_CHANGED=""
fi

# --- DEPLOY DATAPLEX ---
if [ ! -z "$DATAPLEX_CHANGED" ]; then
    echo "Changes detected in Dataplex. Deploying to ${targetenv}..."
    cd "${WORKSPACE_DIR}/terraform_code/envs/${targetenv}/dataplex"
    cp "${WORKSPACE_DIR}/oidc_token.json" .
    
    rm -rf .terraform
    terraform init
    terraform plan -out=tfplan
    terraform apply -auto-approve tfplan
    
    if [[ $? -ne 0 ]]; then 
        echo "Dataplex deployment failed!"
        exit 1
    fi
else
    echo "No Dataplex changes detected."
fi

# --- DEPLOY CLOUD RUN JOBS ---
if [ -z "$ALL_CHANGED_CLOUDRUN" ]; then
    echo "No Cloud Run apps or terraform modules changed. Skipping."
    exit 0
fi

for APP_NAME in $ALL_CHANGED_CLOUDRUN; do
    DIR_NAME_LOWER=$(echo "$APP_NAME" | tr '[:upper:]' '[:lower:]')
    TF_DIR="${WORKSPACE_DIR}/terraform_code/envs/${targetenv}/cloud_run/${DIR_NAME_LOWER}"
    
    if [ -d "$TF_DIR" ]; then
        echo "Deploying Terraform for: ${DIR_NAME_LOWER} in ${targetenv}"
        cd "${TF_DIR}"
        cp "${WORKSPACE_DIR}/oidc_token.json" .
        
        rm -rf .terraform
        terraform init
        
        echo "Clearing any failure taints on the resource..."
        terraform untaint 'module.cloudrun_job.google_cloud_run_v2_job.job' 2>/dev/null
        
        terraform plan -var="image_tag=${GIT_COMMIT_HASH}" -out=tfplan
        terraform apply -auto-approve tfplan
        
        if [[ $? -ne 0 ]]; then 
            echo "Terraform deployment failed for ${DIR_NAME_LOWER}!"
            exit 1
        fi
    else
        echo "Warning: No Terraform directory found at ${TF_DIR}. Skipping."
    fi
done

echo "All modified resources deployed successfully!"