project_id   = "vz-nonit-pr-jyav-dgsdo-0"
region       = "us-east4"
location     = "us-east4"
terraform_sa = "sa-pr-jyav-app-dgsdo-0@vz-nonit-pr-jyav-dgsdo-0.iam.gserviceaccount.com"