variable "project_id" {
  type = string
}

variable "region" {
  type    = string
  default = "us-east4"
}

variable "location" {
  type    = string
  default = "us-east4"
}

variable "terraform_sa" {
  type = string
}

variable "image_tag" {
  description = "The commit hash tag for the container image"
  type        = string
}

