module "cloudrun_job" {
  source = "../../../../custom_modules/cloudrun_job"

  project_id            = var.project_id
  location              = var.location
  job_name              = "vz-profiler-job"
  
  container_image       = "us-east4-docker.pkg.dev/${var.project_id}/gkc-governance-repo/profiler_cloud_run:${var.image_tag}"
  
  service_account_email = var.terraform_sa
  vpc_connector         = "projects/vz-it-pr-exhv-sharedvpc-228020/locations/us-east4/connectors/shared-pr-east"
  vpc_egress            = "ALL_TRAFFIC"
  
  max_retries           = 3
  timeout_seconds       = 10800

  kms_key               = "projects/vz-it-pr-d0sv-vsadkms-0/locations/us-east4/keyRings/vz-nonit-pr-kr-vgs/cryptoKeys/vz-nonit-pr-kms-jyav"

  env_vars = {
    CONFIG_GCS_URI = "gs://jyav-prod-dgsdo-0-usre-gkcenrichment/data/profiler_config.yaml"
  }

  labels = {
    purpose = "vz-profiler-job"
  }
}
