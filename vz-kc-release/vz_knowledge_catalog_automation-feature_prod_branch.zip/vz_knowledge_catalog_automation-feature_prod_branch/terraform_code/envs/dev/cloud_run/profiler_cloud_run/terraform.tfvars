project_id   = "vz-nonit-np-jyav-dev-dgsdo-0"
region       = "us-east4"
location     = "us-east4"
terraform_sa = "sa-dev-jyav-app-dgsdo-0@vz-nonit-np-jyav-dev-dgsdo-0.iam.gserviceaccount.com"